import './App.css';
import './seat.css';

function seat() {
    return (
        <div className="container">
            <h1>Select lower seat</h1><br />
            <div class="containerbus">
                <div class="autobus">

                    <div class="fila">
                        <div class="seccion">
                            <div class="asiento">
                                <input type="checkbox" value="None" id="asientol1" name="check" />
                                <label for="asientol1">l1</label>
                            </div>

                        </div>
                        <div class="seccion">
                            <div class="asiento">
                                <input type="checkbox" value="None" id="asientol2" name="check" />
                                <label for="asientol2">l2</label>
                            </div>
                            <div class="asiento">
                                <input type="checkbox" value="None" id="asientol3" name="check" />
                                <label for="asientol3">l3</label>
                            </div>
                        </div>
                    </div>

                    <div class="fila">
                        <div class="seccion">
                            <div class="asiento">
                                <input type="checkbox" value="None" id="asientol4" name="check" />
                                <label for="asientol4">l4</label>
                            </div>
                        </div>
                        <div class="seccion">
                            <div class="asiento">
                                <input type="checkbox" value="None" id="asientol5" name="check" />
                                <label for="asientol5">l5</label>
                            </div>
                            <div class="asiento">
                                <input type="checkbox" value="None" id="asientol6" name="check" />
                                <label for="asientol6">l6</label>
                            </div>
                        </div>
                    </div>

                    <div class="fila">
                        <div class="seccion">
                            <div class="asiento">
                                <input type="checkbox" value="None" id="asientol7" name="check" />
                                <label for="asientol7">l7</label>
                            </div>
                        </div>
                        <div class="seccion">
                            <div class="asiento">
                                <input type="checkbox" value="None" id="asientol8" name="check" />
                                <label for="asientol8">l8</label>
                            </div>
                            <div class="asiento">
                                <input type="checkbox" value="None" id="asientol9" name="check" />
                                <label for="asientol9">l9</label>
                            </div>
                        </div>
                    </div>

                    <div class="fila">
                        <div class="seccion">
                            <div class="asiento">
                                <input type="checkbox" value="None" id="asientol10" name="check" />
                                <label for="asientol10">l10</label>
                            </div>
                        </div>
                        <div class="seccion">
                            <div class="asiento">
                                <input type="checkbox" value="None" id="asientol11" name="check" />
                                <label for="asientol11">l11</label>
                            </div>
                            <div class="asiento">
                                <input type="checkbox" value="None" id="asientol12" name="check" />
                                <label for="asientol12">l12</label>
                            </div>
                        </div>
                    </div>

                    <div class="fila">
                        <div class="seccion">
                            <div class="asiento">
                                <input type="checkbox" value="None" id="asientol13" name="check" />
                                <label for="asientol13">l13</label>
                            </div>
                        </div>
                        <div class="seccion">
                            <div class="asiento">
                                <input type="checkbox" value="None" id="asientol14" name="check" />
                                <label for="asientol14">l14</label>
                            </div>
                            <div class="asiento">
                                <input type="checkbox" value="None" id="asientol15" name="check" />
                                <label for="asientol15">l15</label>
                            </div>
                        </div>
                    </div>

                    <div class="fila">
                        <div class="seccion">
                            <div class="asiento">
                                <input type="checkbox" value="None" id="asientol16" name="check" />
                                <label for="asientol16">l16</label>
                            </div>
                        </div>
                        <div class="seccion">
                            <div class="asiento">
                                <input type="checkbox" value="None" id="asientol17" name="check" />
                                <label for="asientol17">l17</label>
                            </div>
                            <div class="asiento">
                                <input type="checkbox" value="None" id="asientol18" name="check" />
                                <label for="asientol18">l18</label>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <br /><br />
            <h1>Select Upper seat</h1><br />
            <div class="containerbus">
                <div class="autobus">

                    <div class="fila">
                        <div class="seccion">
                            <div class="asiento">
                                <input type="checkbox" value="None" id="asientou1" name="check" />
                                <label for="asientou1">l1</label>
                            </div>

                        </div>
                        <div class="seccion">
                            <div class="asiento">
                                <input type="checkbox" value="None" id="asientou2" name="check" />
                                <label for="asientou2">u2</label>
                            </div>
                            <div class="asiento">
                                <input type="checkbox" value="None" id="asientou3" name="check" />
                                <label for="asientou3">u3</label>
                            </div>
                        </div>
                    </div>

                    <div class="fila">
                        <div class="seccion">
                            <div class="asiento">
                                <input type="checkbox" value="None" id="asientou4" name="check" />
                                <label for="asientou4">u4</label>
                            </div>
                        </div>
                        <div class="seccion">
                            <div class="asiento">
                                <input type="checkbox" value="None" id="asientou5" name="check" />
                                <label for="asientou5">u5</label>
                            </div>
                            <div class="asiento">
                                <input type="checkbox" value="None" id="asientou6" name="check" />
                                <label for="asientou6">u6</label>
                            </div>
                        </div>
                    </div>

                    <div class="fila">
                        <div class="seccion">
                            <div class="asiento">
                                <input type="checkbox" value="None" id="asientou7" name="check" />
                                <label for="asientou7">u7</label>
                            </div>
                        </div>
                        <div class="seccion">
                            <div class="asiento">
                                <input type="checkbox" value="None" id="asientou8" name="check" />
                                <label for="asientou8">u8</label>
                            </div>
                            <div class="asiento">
                                <input type="checkbox" value="None" id="asientou9" name="check" />
                                <label for="asientou9">u9</label>
                            </div>
                        </div>
                    </div>

                    <div class="fila">
                        <div class="seccion">
                            <div class="asiento">
                                <input type="checkbox" value="None" id="asientou10" name="check" />
                                <label for="asientou10">u10</label>
                            </div>
                        </div>
                        <div class="seccion">
                            <div class="asiento">
                                <input type="checkbox" value="None" id="asientou11" name="check" />
                                <label for="asientou11">u11</label>
                            </div>
                            <div class="asiento">
                                <input type="checkbox" value="None" id="asientou12" name="check" />
                                <label for="asientou12">u12</label>
                            </div>
                        </div>
                    </div>

                    <div class="fila">
                        <div class="seccion">
                            <div class="asiento">
                                <input type="checkbox" value="None" id="asientou13" name="check" />
                                <label for="asientou13">u13</label>
                            </div>
                        </div>
                        <div class="seccion">
                            <div class="asiento">
                                <input type="checkbox" value="None" id="asientou14" name="check" />
                                <label for="asientou14">u14</label>
                            </div>
                            <div class="asiento">
                                <input type="checkbox" value="None" id="asientou15" name="check" />
                                <label for="asientou15">u15</label>
                            </div>
                        </div>
                    </div>

                    <div class="fila">
                        <div class="seccion">
                            <div class="asiento">
                                <input type="checkbox" value="None" id="asientou16" name="check" />
                                <label for="asientou16">u16</label>
                            </div>
                        </div>
                        <div class="seccion">
                            <div class="asiento">
                                <input type="checkbox" value="None" id="asientou17" name="check" />
                                <label for="asientou17">u17</label>
                            </div>
                            <div class="asiento">
                                <input type="checkbox" value="None" id="asientou18" name="check" />
                                <label for="asientou18">u18</label>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <br /><br />
            <div class="butt" style={{marginLeft: '45%'}}>
                &nbsp;&nbsp;&nbsp;&nbsp;<a href="bus_detail.jsp"><input class="btn btn-outline-primary"
                    type="button" value="Back" /></a> &nbsp;
	<a href="file.jsp"><input class="btn btn-outline-success"
                    type="button" value="Next" /></a> &nbsp;
</div>
            <br />
            <br />
        </div>
    );
}
export default seat;
