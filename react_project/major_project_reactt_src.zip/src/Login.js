import 'bootstrap/dist/css/bootstrap.css';
import './login.css';
import './Registration1';
import './home';
import  './bus_detail';
import { useHistory } from "react-router-dom";
import React, { useCallback, useEffect, useState } from "react";
import UserService from './UserService';
import  axios from 'axios';
import api from './UserService';
import swal from "sweetalert";


function Login() {
        const history = useHistory();
        const regex =/^([a-zA-Z0-9_.-])+@(([a-zA-Z0-9-])+\.)+([a-zA-Z0-9]{2,4})+$/;
        //const history = useHistory();
        //const [loginProgress, setLoginProgress] = useState(false);
        const [user, setUser] = useState({
          emailId:"",
          password:""
         
        });
      
       
        const handleLogin = useCallback((e) => {
          e.preventDefault();
         
          if (user.emailId === "" || user.password === "") {
            swal("Oops!", "Please Fill Details!", "error");
            return;
          }
          else if(!regex.test(user.emailId)){
            swal("Error","Please Enter Valid Email Address!","error");
            return;
          } 
          else if(user.password.length< 6)
          {
            swal("!!","Please Enter password with minimum 6 characters","error");
          }
         else {
        
          postlogineonServer(user);
         
         
                  }
                
              
        }, [user]) ;
      
        const postlogineonServer= useCallback((data)=>{
          axios.post(`http://localhost:8080/user/login`,data).then(
            (response)=>{
              
              // setUser(response.data);
              if(user.emailId!== response.data.emailId && user.password!== response.data.password )
              {
                swal("Error","Wrong Login Credentials","error");
              }
              else if(response.data.emailId === 'admin@gmail.com' && response.data.password === 'admin123')
              {
                swal("Success","Admin login Successfully","success");
                console.log(user);
                sessionStorage.setItem("User Data",JSON.stringify(response.data));
                history.push("/bus_detail");
              }
              else
              { 
                swal("Success", "Login Successfully!", "success");
                console.log(user);
                sessionStorage.setItem("User Data",JSON.stringify(response.data));
              //   setUser({emailId:"",
              //   password:""
              //  })
                history.push("/");
      
          
          
              }
                                 
              
            })
            .catch((error)=>{
              console.log("Something went wrong");
            }
          )
        }, [user])
        //console.log(user);
      
    return (
        <div>
            <br/>
            <div className="container h-100">
                <div className="row h-100 justify-content-center align-items-center">
                    <form className="col-md-9">
                        <div className="AppForm shadow-lg">
                            <div className="row">
                                <div className="col-md-6 d-flex justify-content-center align-items-center">
                                    <div className="AppFormLeft">

                                        <h1>Login</h1>
                                        <div className="form-group position-relative mb-4">
                                            <input type="text" className="form-control border-top-0 border-right-0 border-left-0 rounded-0 shadow-none" id="username"
                                                placeholder="Username"   onChange={(e) => setUser({ ...user, emailId: e.target.value })}/>
                                            <i className="fa fa-user-o"></i>
                                        </div>
                                        <div className="form-group position-relative mb-4">
                                            <input type="password" className="form-control border-top-0 border-right-0 border-left-0 rounded-0 shadow-none" id="password"
                                                placeholder="Password" 
                                                onChange={(e) => setUser({ ...user, password: e.target.value })}/>
                                            <i className="fa fa-key"></i>

                                        </div>
                                        <div className="row  mt-4 mb-4">
                                            <div className="col-md-6">
                                                <div className="form-check">
                                                    <input className="form-check-input" type="checkbox" value="" id="defaultCheck1" />
                                                    <label className="form-check-label" for="defaultCheck1">
                                                        Remember me
                                        </label>
                                                </div>
                                            </div>
                                            <div className="col-md-6 text-right">
                                                <a href="#">Forgot Password?</a>
                                            </div>
                                        </div>

                                        {/* <a href="/bus_detail">*/}
                                        <button className="btn btn-success btn-block shadow border-0 py-2 text-uppercase " onClick={handleLogin}> 
                                            Login
                                        </button>
                                        {/* </a> */}

                                        <p className="text-center mt-5">
                                            Don't have an account?
                                <a href="/Registration1"><span>
                                                Create your account
                                </span></a>

                                        </p>

                                    </div>

                                </div>
                                <div className="col-md-6">
                                    <div className="AppFormRight position-relative d-flex justify-content-center flex-column align-items-center text-center p-5 text-white">
                                        <h2 className="position-relative px-4 pb-3 mb-4">Welcome</h2>
                                        <p>On this Site You Can Book Seat For Your Travel World</p>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </form>
                </div>
            </div>
            <br />
        </div>
    );
}

export default Login;