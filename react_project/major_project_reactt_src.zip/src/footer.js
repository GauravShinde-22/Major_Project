import logo from './logo.svg';
import './footer.css';
import 'bootstrap/dist/css/bootstrap.css';

function footer() {
    return (
                <div className="container h-100"><br/>
        <div class="text-center text-lg-start text-dark"
            style={{backgroundColor: '#ECEFF1'}}>
            <section class="d-flex justify-content-between p-4 text-white"
                style={{backgroundColor: '#21D192'}}>
                <div class="me-5">
                    <span>Get connected with us on social networks:</span>
                </div>    <div>
                    <ul>
                        <li><span class="social-icon social-facebook"><i
                            class="fa fa-facebook"></i></span></li>
                        <li><span class="social-icon social-google"><i
                            class="fa fa-google"></i></span></li>
                        <li><span class="social-icon social-linkedin"><i
                            class="fa fa-linkedin"></i></span></li>
                        <li><span class="social-icon social-instagram"><i
                            class="fa fa-instagram"></i></span></li>
                        <li><span class="social-icon social-twitter"><i
                            class="fa fa-twitter"></i></span></li>
                    </ul>
                </div>
            </section>
            <section class="">
                <div class="container1 text-center text-md-start mt-5">
                    <div class="row mt-3">
                        <div class="col-md-3 col-lg-4 col-xl-3 mx-auto mb-4">
                            <h3 class="text-uppercase fw-bold">Foodies Travels</h3>
                            <hr class="mb-4 mt-0 d-inline-block mx-auto"
                                style={{width: '60px', backgroundColor: '#7c4dff', height: '2px'}} />
                            <p >We provide you delicious food
                    with best journey Experiance....!!!</p>
                        </div>
                        <div class="col-md-2 col-lg-2 col-xl-2 mx-auto mb-4">
                            <h6 class="text-uppercase fw-bold">Products</h6>
                            <hr class="mb-4 mt-0 d-inline-block mx-auto"
                                style={{width: '60px', backgroundColor: '#7c4dff', height: '2px'}} />
                            <p>
                                <a href="#!" class="text-dark">Book Ticket</a>
                            </p>
                            <p>
                                <a href="#!" class="text-dark">Food Gallary</a>
                            </p>
                            <p>
                                <a href="#!" class="text-dark">Sign In</a>
                            </p>
                            <p>
                                <a href="#!" class="text-dark">Carrers</a>
                            </p>
                        </div>
                        <div class="col-md-3 col-lg-2 col-xl-2 mx-auto mb-4">
                            <h6 class="text-uppercase fw-bold">Useful links</h6>
                            <hr class="mb-4 mt-0 d-inline-block mx-auto"
                                style={{width: '60px', backgroundColor: '#7c4dff', height: '2px'}} />
                            <p>
                                <a href="#!" class="text-dark">Your Account</a>
                            </p>
                            <p>
                                <a href="#!" class="text-dark">Become an Affiliate</a>
                            </p>
                            <p>
                                <a href="#!" class="text-dark">Reviews</a>
                            </p>
                            <p>
                                <a href="#!" class="text-dark">Help</a>
                            </p>
                        </div>
                        <div class="col-md-4 col-lg-3 col-xl-3 mx-auto mb-md-0 mb-4">
                            <h6 class="text-uppercase fw-bold">Contact</h6>
                            <hr class="mb-4 mt-0 d-inline-block mx-auto"
                                style={{width: '60px', backgroundColor: '#7c4dff', height: '2px'}} />
                            <p>
                                <i class="fas fa-home mr-3"></i> Foodies Travels, 107, Main
                    Street, Pune
                </p>
                            <p>
                                <i class="fas fa-envelope mr-3"></i> foodiestravels@gmail.com
                </p>
                            <p>
                                <i class="fas fa-phone mr-3"></i> + 91 234 999 99
                </p>
                            <p>
                                <i class="fas fa-print mr-3"></i> + 91 234 888 99
                </p>
                        </div>
                    </div>
                </div>
            </section>

            <div class="text-center p-3"
                style={{backgroundColor: 'rgba(0, 0, 0, 0.2)'}}>
                © 2020 Copyright: <a class="text-dark"
                    href="https://mdbootstrap.com/">www.foodiestravel.com</a>
            </div>
        </div>
        </div>
    );
}    
export default footer;