import './App.css';
import { BrowserRouter as Router, Switch, Route } from 'react-router-dom';
import 'bootstrap/dist/css/bootstrap.css';

import Nav from './Nav';
import Home from './home';
import Carousel1 from './Carousel1';
import Footer from './footer';
import Seat from './seat';
import Bus from './bus_detail';
import Login from './Login';
import Registration from './Registration1';

function App() {
	return (

		<Router>


			<Nav />
			<Switch>
				<Route exact path="/">
					<Carousel1 />
					<br /><br />
					<Home />

				</Route>
				<Route exact path="/bus_detail" component={Bus} />
				<Route exact path="/seat" component={Seat} />
				<Route exact path="/login" component={Login}/>
				{/* <Route exact path="/register" component={Register}/> */}
				<Route exact path="/registration1" component={Registration}/>
			</Switch>
			<Footer />
			{/* <Switch>
   <Route exact path="/">
	 <Carsoul />
	 <Cards/>
	 <br /><br />
	 <FlipKard/>
   </Route>
   
  
   <Route exact path="/AboutUs" component={AboutUs} />
   <Route exact path="/ContactUs" component={ContactUs} />
   <Route exact path="/Form" component={Form} />
   <Route exact path="/HallForm" component={HallForm} />
   <Route exact path="/Login" component={Login} />
   <Route exact path="/Signup" component={Signup} />    
	 
 </Switch>     */}

		</Router>



	);
}
export default App;