import 'bootstrap/dist/css/bootstrap.css';
import './seat';

function bus_detail(){
    return(
<div className="container">
<div className="card text-center ">
  <div className="card-body">
      <div className="row">
    <div className="col-sm-2 border border-success" style={{backgroundColor:'orange'}}>
      20 buses<br/>
	  found
	  <br/>
      
    </div>
    <div className="col-sm-2" style={{backgroundColor:'orange'}}>
      Departure<br/>

    </div>
	<div className="col-sm-2" style={{backgroundColor:'orange'}}>
      Duration<br/>  
    </div>
	<div className="col-sm-2" style={{backgroundColor:'orange'}}>
  
Arrival	  
    </div>
	
	<div className="col-sm-2" style={{backgroundColor:'orange'}}>
      Rating
  
    </div>
	<div className="col-sm-2" style={{backgroundColor:'orange'}}>
    Fare <br/>  seat available<br/>
    </div>
  </div>
 
 
 <div className="row">
 
  <div className="card-body">
 
      <div className="row">
    <div className="col-sm-2 border border-success" style={{backgroundColor:'pink'}}>
      orange travels<br/>
	  A/C sleeper (2+1)
	  <br/>
      symbol.
    </div>
    <div className="col-sm-2" style={{backgroundColor:'pink'}}>
      6:30am<br/>
baghnath square	 <br/> 
live tracking
    </div>
	<div className="col-sm-2" style={{backgroundColor:'pink'}}>
      15h 00m<br/>
2 break	  
    </div>
	<div className="col-sm-2" style={{backgroundColor:'pink'}}>
      9:30 am
<br/>25 feb
<br/>sangmwadi	  
    </div>
	
	<div className="col-sm-2" style={{backgroundColor:'pink'}}>
      4star
	  <br/>
<br/>95 people	  
    </div>
	<div className="col-sm-2" style={{backgroundColor:'pink'}}>
      start from
	  INR 1000. 
<br/>FOOD by 100<br/>
  <a href="/seat"><input className="btn btn-outline-primary" type="button" value="book your"/></a>	  
    </div>
  </div>
  <div className="card-footer text-muted">
    Happy Journey
 </div></div></div>
 
 
 <div className="row">
 
   <div className="card-header" style={{backgroundColor:'green'}}>
    orange travel
  </div>
  <div className="card-body">

      <div className="row">
    <div className="col-sm-2 border border-success" style={{backgroundColor:'pink'}}>
      orange travels<br/>
	  A/C sleeper (2+1)
	  <br/>
      symbol.
    </div>
    <div className="col-sm-2" style={{backgroundColor:'pink'}}>
      6:30am<br/>
baghnath square	 <br/> 
live tracking
    </div>
	<div className="col-sm-2" style={{backgroundColor:'pink'}}>
      15h 00m<br/>
2 break	  
    </div>
	<div className="col-sm-2" style={{backgroundColor:'pink'}}>
      9:30 am
<br/>25 feb
<br/>sangmwadi	  
    </div>
	
	<div className="col-sm-2" style={{backgroundColor:'pink'}}>
      4star
	  <br/>
<br/>95 people	  
    </div>
	<div className="col-sm-2" style={{backgroundColor:'pink'}}>
      start from
	  INR 1000. 
<br/>FOOD by 100<br/>
  <a href="/seat"><input className="btn btn-outline-primary" type="button" value="book your"/></a>	  
    </div>
  </div>
  <div className="card-footer text-muted">
    Happy Journey
 </div></div></div>


 <div className="row">
 
   <div className="card-header" style={{backgroundColor:'green'}}>
    orange travel
  </div>
  <div className="card-body">

  
      <div className="row">
    <div className="col-sm-2 border border-success" style={{backgroundColor:'pink'}}>
      orange travels<br/>
	  A/C sleeper (2+1)
	  <br/>
      symbol.
    </div>
    <div className="col-sm-2" style={{backgroundColor:'pink'}}>
      6:30am<br/>
baghnath square	 <br/> 
live tracking
    </div>
	<div className="col-sm-2" style={{backgroundColor:'pink'}}>
      15h 00m<br/>
2 break	  
    </div>
	<div className="col-sm-2" style={{backgroundColor:'pink'}}>
      9:30 am
<br/>25 feb
<br/>sangmwadi	  
    </div>
	
	<div className="col-sm-2" style={{backgroundColor:'pink'}}>
      4star
	  <br/>
<br/>95 people	  
    </div>
	<div className="col-sm-2" style={{backgroundColor:'pink'}}>
      start from
	  INR 1000. 
<br/>FOOD by 100	<br/>
  <a href="/seat"><input className="btn btn-outline-primary" type="button" value="book your"/></a>  
    </div>
  </div>
  <div className="card-footer text-muted">
    Happy Journey
 </div>
 </div></div>


 <div className="row">
 
   <div className="card-header" style={{backgroundColor:'green'}}>
    orange travel
  </div>
  <div className="card-body">
    
      <div className="row">
    <div className="col-sm-2 border border-success" style={{backgroundColor:'pink'}}>
      orange travels<br/>
	  A/C sleeper (2+1)
	  <br/>
      symbol.
    </div>
    <div className="col-sm-2" style={{backgroundColor:'pink'}}>
      6:30am<br/>
baghnath square	 <br/> 
live tracking
    </div>
	<div className="col-sm-2" style={{backgroundColor:'pink'}}>
      15h 00m<br/>
2 break	  
    </div>
	<div className="col-sm-2" style={{backgroundColor:'pink'}}>
      9:30 am
<br/>25 feb
<br/>sangmwadi	  
    </div>
	
	<div className="col-sm-2" style={{backgroundColor:'pink'}}>
      4star
	  <br/>
<br/>95 people	  
    </div>
	<div className="col-sm-2" style={{backgroundColor:'pink'}}>
      start from
	  INR 1000. 
<br/>FOOD by 100	<br/>
  <a href="/seat"><input className="btn btn-outline-primary" type="button" value="book your"/></a>  
    </div>
  </div>
  <div className="card-footer text-muted">
    Happy Journey
 </div>
</div>
</div>


 <div className="row">
 
   <div className="card-header" style={{backgroundColor:'green'}}>
    orange travel
  </div>
  <div className="card-body">

      <div className="row">
    <div className="col-sm-2 border border-success" style={{backgroundColor:'pink'}}>
      orange travels<br/>
	  A/C sleeper (2+1)
	  <br/>
      symbol.
    </div>
    <div className="col-sm-2" style={{backgroundColor:'pink'}}>
      6:30am<br/>
baghnath square	 <br/> 
live tracking
    </div>
	<div className="col-sm-2" style={{backgroundColor:'pink'}}>
      15h 00m<br/>
2 break	  
    </div>
	<div className="col-sm-2" style={{backgroundColor:'pink'}}>
      9:30 am
<br/>25 feb
<br/>sangmwadi	  
    </div>
	
	<div className="col-sm-2" style={{backgroundColor:'pink'}}>
      4star
	  <br/>
<br/>95 people	  
    </div>
	<div className="col-sm-2" style={{backgroundColor:'pink'}}>
      start from
	  INR 1000. 
<br/>FOOD by 100	 <br/>
  <a href="/seat"><input className="btn btn-outline-primary" type="button" value="book your"/></a> 
    </div>
  </div>
  <div className="card-footer text-muted">
    Happy Journey
 </div>
</div></div>



 <div className="row">
 
   <div className="card-header" style={{backgroundColor:'green'}}>
    orange travel
  </div>
  <div className="card-body">

      <div className="row">
    <div className="col-sm-2 border border-success" style={{backgroundColor:'pink'}}>
      orange travels<br/>
	  A/C sleeper (2+1)
	  <br/>
      symbol.
    </div>
    <div className="col-sm-2" style={{backgroundColor:'pink'}}>
      6:30am<br/>
baghnath square	 <br/> 
live tracking
    </div>
	<div className="col-sm-2" style={{backgroundColor:'pink'}}>
      15h 00m<br/>
2 break	  
    </div>
	<div className="col-sm-2" style={{backgroundColor:'pink'}}>
      9:30 am
<br/>25 feb
<br/>sangmwadi	  
    </div>
	
	<div className="col-sm-2" style={{backgroundColor:'pink'}}>
      4star
	  <br/>
<br/>95 people	  
    </div>
	<div className="col-sm-2" style={{backgroundColor:'pink'}}>
      start from
	  INR 1000. 
<br/>FOOD by 100	 <br/>
  <a href="/seat"><input className="btn btn-outline-primary" type="button" value="book your"/></a> 
    </div>
  </div>
  <div className="card-footer text-muted">
    Happy Journey
 </div>

</div> 
</div>


<br/><br/>

</div>
</div>
</div>
    );
    } 

export default bus_detail;    