import './App.css';
import './home.css';
import Bus from './bus_detail';
import { Button, Card } from 'react-bootstrap';
import logo_1 from "./Images/logo_for_page_1_about.jpg";
function home() {
	return (
		<div className="container">
			<div className="row my_search" style={{ backgroundImage: `url(https://images.cdn1.stockunlimited.net/preview1300/travel-wallpaper_1712795.jpg)` }}>
				<div className="col-12">
					<div className="row">
						<div className="col-3"></div>
						<div className="col-6" style={{marginLeft:'100px'}}>
							<div className="mt-1">
								<input name="start" className=" form-control-lg"
									type="text" placeholder="Starting Point" />
										&nbsp;&nbsp;&nbsp;

								<input name="end" className=" form-control-lg"
									type="text" placeholder="Ending Point" />
								<br />
							</div>
							<div className="col-3"></div>
						</div>
						<div className="row">
							<div className="col-3"></div>
							<div className="col-6" >
								<form style={{marginLeft:'100px'}}>
									<br />&nbsp;&nbsp;&nbsp;<label className="form-control-lg" for="select_date">Date:</label> <input type="date"
										id="enter date" className="form-control-lg" name="book ticket date" />
								</form>
							</div>
							<div className="col-3"></div>
						</div>

						<div className="row">
							<div className="col-3"></div>
							<div className="col-6" style={{marginLeft:'230px'}}>
								<br />
								<br />
									<a href="/bus_detail"><input className="btn btn-secondary" type="submit"
										value="Search" /></a>
								&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
									<a href="home.jsp"><input className="btn btn-secondary"
										type="button" value="Cancel" /></a>
							</div>
							<div className="col-3"></div>
						</div>
					</div>
				</div>
			</div>
			<br />
			<div className="row">
				<div className="col-2"></div>
				<div className="col-8">

					<Card className="text-center">
						<Card.Header><h3>Featured</h3></Card.Header>
						<Card.Body>
							<Card.Title><img class="img2_Hero" src={logo_1} alt="" />
								<h5>Introducing Safety+</h5>
							</Card.Title>
							<Card.Text>
								<div class="row">
									<div class="col-4">
										<b style={{ color: "#4a4376" }}>Sanitized Bus</b>
										<br />All Safety+ buses are sanitized and<br /> disinfected before and after every trip.
					     </div>
									<div class="col-4">
										<b style={{ color: "#4a4376" }}>Mandatory masks</b>
										<br />Proper masks are mandatory for<br /> all passengers and bus staff.
					     </div>
									<div class="col-4">
										<b style={{ color: "#4a4376" }}>Thermal Screening</b>
										<br />All passengers will undergo thermal screening.
						<br />Temperature checks for bus drivers and service <br />staff are done before every trip.
					     </div>
								</div>
							</Card.Text>
							<Button variant="primary">Go somewhere</Button>
						</Card.Body>
						<Card.Footer className="text-muted">2 days ago</Card.Footer>
					</Card>

					{/* <div class="card text-center">
				<div class="card-header"><h3>Featured</h3></div>
				 <div class="card-body">
		            <img class="img2_Hero"
				src="/Images/logo_for_page_1_about.jpg" alt=""/>
					<h5 class="card-title">Introducing Safety+</h5>
				</div>
			</div> */}
				</div>
				<div className="col-2"></div>
			</div>
		</div>
	);
}
export default home;