import './App.css';
import './Login';
import  './home';
import './register';
import  './Registration1';
import 'bootstrap/dist/css/bootstrap.css';

function Nav() {
	return (
		<div>
			<div className="container">
				<nav className="navbar navbar-expand-lg navbar-light bg-light">
					<div className="container-fluid">
						{/* <div className="row">
        <div className="col-8"> */}
						<a href="/" className="navbar-brand">Foodies Travels</a>
						<button className="navbar-toggler" type="button"
							data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent"
							aria-controls="navbarSupportedContent" aria-expanded="false"
							aria-label="Toggle navigation">
							<span className="navbar-toggler-icon"></span>
						</button>
						<div className="collapse navbar-collapse" id="navbarSupportedContent">
							<ul className="navbar-nav me-auto mb-2 mb-lg-0">
								<li className="nav-item dropdown"><a
									className="nav-link dropdown-toggle" href="#" id="navbarDropdown"
									role="button" data-bs-toggle="dropdown" aria-expanded="true">
									Features </a>
									<ul className="dropdown-menu" aria-labelledby="navbarDropdown">
										<li><a className="dropdown-item" href="#">Book Trip</a></li>
										<li><a className="dropdown-item" href="#">Book Order</a></li>
										<li><a className="dropdown-item" href="9.jsp">Print Ticket</a></li>
										<li><a className="dropdown-item" href="#">Something else
									here</a></li>
									</ul></li>

								<li className="nav-item dropdown"><a
									className="nav-link dropdown-toggle" href="#" id="navbarDropdown"
									role="button" data-bs-toggle="dropdown" aria-expanded="true">
									Bus Ticket </a>
									<ul className="dropdown-menu" aria-labelledby="navbarDropdown">
										<li><a className="dropdown-item" href="seat.jsp">Book Ticket</a></li>
										<li><a className="dropdown-item" href="9.jsp">View Ticket</a></li>
										<li><a className="dropdown-item" href="#">Cancel Ticket</a></li>
										<li><a className="dropdown-item" href="#">Something else
									here</a></li>
									</ul></li>
								<li className="nav-item"><a className="nav-link" href="#">Food
							Menu</a></li>
								<li className="nav-item"><a className="nav-link" href="contactus.jsp">Contact
							Us</a></li>
								<li className="nav-item"><a className="nav-link" href="#">Careers</a>
								</li>
							</ul>

							{/* </div></div> */}
							{/* <div className="col-4"> */}
							<form className="d-flex" style={{ marginLeft: "150px" }}>
								<input className="form-control me-2" type="search" placeholder="Search"
									aria-label="Search" />

								<button className="btn btn-outline-success mr-4" type="submit">Search</button>
					&nbsp;
					{/* <a href="login.jsp"><button className="btn btn-outline-primary" type="submit">Login</button></a> */}
                    &nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;
				<a href="/login"><input className="btn btn-outline-primary" type="button" value="Login" /></a>
					&nbsp;
					<a href="/registration1"><input className="btn btn-outline-success" type="button" value="SingUp" /></a>
					&nbsp;
				</form>
						</div>
					</div>
					{/* </div> */}
				</nav>
			</div>
		</div>
	);
}

export default Nav; 