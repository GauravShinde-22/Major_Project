import "bootstrap/dist/css/bootstrap.css";
import "./login.css";
import UserService from "./UserService";
import React ,{ useState, useEffect } from "react";
import swal from "sweetalert";

    

function Registration1  ()  {
    
    const regex =/^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
    const regex1=/^([a-zA-Z])+$/;
    const regex2=/^([0-9])/;
    //const regex3=/^[2-9]{1}[0-9]{3}\s{1}[0-9]{4}\s[0-9]{4}$/;

    const [user, setUser] = useState({
        firstName: "",
        lastName: "",
        userName:"",
        emailId: "",
        password: "",
        mobileNo:"",
        address :"",
        conformpassword:""
      });

  const registerUser = (e) => {
    e.preventDefault();
    console.log(user);
    
     if (
        
       user.firstName === "" ||  
       user.lastName === "" ||
       user.emailId === "" ||
       user.password === ""||
       user.mobileNo === ""||
       user.conformPassword === ""||
       user.address ==="" )
     {
       swal("Oops!", "Please Fill Details!", "error");
     }
    else if(!regex1.test(user.firstName)){
        swal("Error!","Please Enter Valid name","error");
      
    }
    else if(!regex1.test(user.lastName)){
        swal("Error!","Please Enter Valid Lastname","error");
        
    }

    else if (!regex.test(user.emailId))
    {
      swal("Error!","Please Enter Valid Email Address","error");
     
    } 
    else if(user.password.length< 6)
    {
      swal("Error!","Please Enter password with minimum 6 characters","error");
      
    }
    
    else if(user.password !== user.conformpassword)
    {
        swal("Error","Password Dont Match","error");
    }
    else if(!regex2.test(user.mobileNo) || user.mobileNo.length <10){
        swal("Error!!","Please Enter mobileNo with minimum 10 characters","error");
        
    }
    else {
        console.log(user);
        UserService.postUser(user);
        setUser({firstName: "",
      lastName: "",
      userName:"",
      emailId: "",
      password: "",
      mobileNo:"",
      address :"",
      conformpassword:""
    })
      
    setTimeout(() => {
        swal("Success!", "Registered successfully!", "success");
    }, 500); 
        
    }
  };

 
    return (
        <div className="container h-100">
      <div class="page-wrapper bg-gra-02 p-t-130 p-b-100 font-poppins">
        <div class="wrapper wrapper--w680 bg bg-primary  ">
            <div class="card card-4 ">
                <div class="card-body ">
                    <h2 class="title" style={{textAlign:'center'}}>User Registration Form</h2><br/>
                    <form>

                    <div class="container h-100">
            <div class="row h-100 justify-content-center align-items-center">
                <form class="col-md-9">
                    <div class="AppForm shadow-lg">
                        <div class="row">
                            <div class="col-md-6 d-flex justify-content-center align-items-center">
                                <div class="AppFormLeft">

                                    <h1 style={{color:'black'}}>Registration</h1><br/>
                                    <div class="form-group position-relative mb-4">
                                        <input type="text" class="form-control border-top-0 border-right-0 border-left-0 rounded-0 shadow-none" name="firstName"
                                            placeholder="Firstname" value={user.firstName} onChange={(e) => setUser({ ...user, firstName: e.target.value })} />
                                    </div>
                                    <div class="form-group position-relative mb-4">
                                        <input type="text" class="form-control border-top-0 border-right-0 border-left-0 rounded-0 shadow-none" name="lastName"
                                            placeholder="Lastname" value={user.lastName} onChange={(e) => setUser({ ...user, lastName: e.target.value })} />
                                    </div>
                                    <div class="form-group position-relative mb-4">
                                        <input type="text" class="form-control border-top-0 border-right-0 border-left-0 rounded-0 shadow-none" name="userName"
                                            placeholder="Username" value={user.userName}
                                            onChange={(e) => setUser({ ...user, userName: e.target.value })}/>
                                    </div>
                                    <div class="form-group position-relative mb-4">
                                        <input type="password" class="form-control border-top-0 border-right-0 border-left-0 rounded-0 shadow-none" name="password"
                                            placeholder="Password" value={user.password}
                                            onChange={(e) => setUser({ ...user, password: e.target.value })}/>
                                    </div>
                                    
                                    <div class="form-group position-relative mb-4">
                                        <input type="password" class="form-control border-top-0 border-right-0 border-left-0 rounded-0 shadow-none" name="conformpassword"
                                            placeholder="ConformPassword" value={user.conformpassword}
                                            onChange={(e) => setUser({ ...user, conformpassword: e.target.value })}/>
                                    </div>

                                    <div class="form-group position-relative mb-4">
                                        <input type="text" class="form-control border-top-0 border-right-0 border-left-0 rounded-0 shadow-none" name="email"
                                            placeholder="email" value={user.emailId}
                                            onChange={(e) => setUser({ ...user, emailId: e.target.value })}/>

                                    </div>

                                    <div class="form-group position-relative mb-4">
                                        <input type="text" class="form-control border-top-0 border-right-0 border-left-0 rounded-0 shadow-none" name="address"
                                            placeholder="Address" value={user.address} onChange={(e) => setUser({ ...user, address: e.target.value })} />
                                    </div>

                                    

                                    <div class="form-group position-relative mb-4">
                                        <input type="text" class="form-control border-top-0 border-right-0 border-left-0 rounded-0 shadow-none" name="mobile"
                                            placeholder="Mobile No." value={user.mobileNo}
                                            onChange={(e) => setUser({ ...user, mobileNo: e.target.value })}/>
                                    </div>
                                    <button class="btn btn-success btn-block shadow border-0 py-2 text-uppercase " onClick={registerUser}>
                                        Submit
                         </button>

                                    <p class="text-center mt-5">
                                        <a href="/login"><span >
                                            Login Your Account
                             </span></a>

                                    </p>

                                </div>

                            </div><br />
                            <div class="col-md-6">
                                <br/><br/>
                                <div class="AppFormRight position-relative d-flex justify-content-center flex-column align-items-center text-center p-5 text-white">
                                    <h2 class="position-relative px-4 pb-3 mb-4">Welcome</h2>
                                    <p>On this Site You Can Book Seat For Your Travel World</p>
                                </div>
                            </div>
                        </div>
                    </div>

                </form>
            </div>
        </div>


                          
                        
                    </form>
                </div>
            </div>
        </div>
    </div>
    </div> 
    );
}
export default Registration1;